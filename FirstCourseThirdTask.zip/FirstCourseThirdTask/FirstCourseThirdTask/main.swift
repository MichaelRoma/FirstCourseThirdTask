// Этот файл пуст не по ошибке. В этот раз вам необходимо самостоятельно импортировать необходимые модули и запустить проверку
//Добавляем все необходимые модули
import Foundation
import FirstCourseThirdTaskChecker


let checker = Checker()



//Задание 1

class StackLIFO:  ArrayInitializableStorage {
    
    private var privateStorage: [Int] = []
    override var count: Int { privateStorage.count }
    
   required init(array: [Int]) {
    privateStorage = array
    super.init()
    }
    
    
    required init() {
        super.init()
    }
    
  override  func push (_ element: Int) {
        privateStorage.append(element)
    }
    
    override func pop () -> Int {
        privateStorage.removeLast()
    }
    
}

class QueueFIFO:  ArrayInitializableStorage {
    
    private var privateStorage: [Int] = []
    override var count: Int { privateStorage.count }
    
    required init(array: [Int]) {
      super.init()
      privateStorage = array
      }
    required init() {
        super.init()
    }
    
    override func push (_ element: Int) {
        privateStorage.append(element)
    }
    
    override func pop () -> Int {
        privateStorage.removeFirst()
    }
    
}

let stack = StackLIFO()
let queue = QueueFIFO()

//Проверяем решение
checker.checkInheritance (stack: stack, queue: queue)

//Задание 2

struct StackLIFOStruck:  ArrayInitializable, StorageProtocol {
    
    private var privateStorage: [Int] = []
    var count: Int { privateStorage.count }
    
    init() {}
    
    init(array: [Int]) {
    privateStorage = array
    }

    mutating func push (_ element: Int) {
        privateStorage.append(element)
    }

    mutating func pop () -> Int {
        privateStorage.removeLast()
    }
    
}

struct QueueFIFOStruct:  ArrayInitializable, StorageProtocol {
    
    private var privateStorage: [Int] = []
    var count: Int { privateStorage.count }

    init() {}
    
    init(array: [Int]) {
    privateStorage = array
    }
    
    mutating func push (_ element: Int) {
        privateStorage.append(element)
    }
    
    mutating func pop () -> Int {
        privateStorage.removeFirst()
    }
    
}

let stackStruck = StackLIFOStruck()
let queueStruck = QueueFIFOStruct()

//Проверка решения
checker.checkProtocols(stack: stackStruck, queue: queueStruck)


//Задание 3
//Сделаем под каждый протокол свой extension, для удобства и читабильности кода

extension User: JSONInitializable {
    public convenience init(JSON: String) {
        self.init()
        
        //Создадим функцию, которая будет переводить строку JSON в словарь JSON
     func convertToDictionary(text: String) -> [String: String]? {
         if let data = text.data(using: .utf8) {
             do {
                 return try JSONSerialization.jsonObject(with: data, options: []) as? [String: String]
             } catch {
                 print(error.localizedDescription)
             }
         }
         return nil
     }
        
     let jsonString = JSON
        //Мы сразу знаем, что там будет данные, поэтому принудительно разворачиваем опционал
     let jsonDict = convertToDictionary(text: jsonString)!
        
        fullName = jsonDict["fullName"]!
        email = jsonDict["email"]!
        

    }

}

extension User: JSONSerializable {
    public func toJSON() -> String {
        //можно убрать переменную ниже, то так удобней работать с текстом, как мне кажется
      let a = "{\"fullName\": " + "\"\(fullName)\"" + ", \"email\": " + "\"\(email)\"}"
        return a
    }
}

//Проверка решения
checker.checkExtensions(userType: User.self)


