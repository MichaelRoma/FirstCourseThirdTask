// Этот файл пуст не по ошибке. В этот раз вам необходимо самостоятельно импортировать необходимые модули и запустить проверку
//Добавляем все необходимые модули
import Foundation
import FirstCourseThirdTaskChecker


let checker = Checker()



//Задание 1

class StackLIFO:  ArrayInitializableStorage {
    
    private var privateStorage: [Int] = []
    override var count: Int { privateStorage.count }
    
   required init(array: [Int]) {
    super.init(array: array)
    privateStorage = array
    }
    
    required init() {
        super.init()
    }
    
  override  func push (_ element: Int) {
        privateStorage.append(element)
    }
    
    override func pop () -> Int {
        privateStorage.removeLast()
    }
    
}

class QueueFIFO:  ArrayInitializableStorage {
    
    private var privateStorage: [Int] = []
    override var count: Int { privateStorage.count }
    
    required init(array: [Int]) {
      super.init(array: array)
      privateStorage = array
      }
    required init() {
        super.init()
    }
    
    override func push (_ element: Int) {
        privateStorage.append(element)
    }
    
    override func pop () -> Int {
        privateStorage.removeFirst()
    }
    
}

let stack = StackLIFO()
let queue = QueueFIFO()

//Проверяем решение
checker.checkInheritance (stack: stack, queue: queue)

//Задание 2

struct StackLIFOStruck:  ArrayInitializable, StorageProtocol {
    
    private var privateStorage: [Int] = []
    var count: Int { privateStorage.count }
    
    init() {}
    
    init(array: [Int]) {
    privateStorage = array
    }

    mutating func push (_ element: Int) {
        privateStorage.append(element)
    }

    mutating func pop () -> Int {
        privateStorage.removeLast()
    }
    
}

struct QueueFIFOStruct:  ArrayInitializable, StorageProtocol {
    
    private var privateStorage: [Int] = []
    var count: Int { privateStorage.count }

    init() {}
    
    init(array: [Int]) {
    privateStorage = array
    }
    
    mutating func push (_ element: Int) {
        privateStorage.append(element)
    }
    
    mutating func pop () -> Int {
        privateStorage.removeFirst()
    }
    
}

let stackStruck = StackLIFOStruck()
let queueStruck = QueueFIFOStruct()

//Проверка решения
checker.checkProtocols(stack: stackStruck, queue: queueStruck)


//Задание 3
//Сделаем под каждый протокол свой extension, для удобства и читабильности кода

extension User: JSONInitializable {
    public convenience init(JSON: String) {
        self.init()
        
        //Так как нам четко известна строка которая должна прийти, то можем посчитать элементы, которые надо отбросить
        //Данный вариант "топорный" и если, что пойдет не так, например имя будет дленее, то он не сработает.
        fullName = String(JSON.dropFirst(14).dropLast(31))
        email = String(JSON.dropFirst(48).dropLast(2))
        //Нам четко извества структура строки, которая должны прийти, неизвестно только длина полей, но известно сколько можно сразу отбросить dropFirst(14) - вначале строки и dropLast(2) с конца строки.
        
        //Хороший вариант решения. Так как мы знаем структуру строки, можно использовать функцию split() для разбития строки сепаратором "(кавычки), а потом присвоить каждой переменной необходимый элементы коллекции, который определяем по структуре строки. В данном варианте длина значение не играет роли, важна структура самой строки
        fullName = String(JSON.split(separator: "\"")[3])
        email = String(JSON.split(separator: "\"")[7])
    }

}

extension User: JSONSerializable {
    public func toJSON() -> String {
        //можно убрать переменную ниже, то так удобней работать с текстом, как мне кажется
      let a = "{\"fullName\": " + "\"\(fullName)\"" + ", \"email\": " + "\"\(email)\"}"
        return a
    }
}

//Проверка решения
checker.checkExtensions(userType: User.self)


